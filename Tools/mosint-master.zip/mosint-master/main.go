// mosint v2.2
// Author: Alp Keskin
// Github: github.com/alpkeskin
// Linkedin: linkedin.com/in/alpkeskin

package main

import "github.com/alpkeskin/mosint/cmd"

func main() {
	cmd.Execute()
}
