# Kali-Nethunter
> Hey there, This is my new script. Which will help you to install Kali Nethunter (OR Kali-Linux) Rootless version in your android device without rooting your android device. This will install CLI Mode and GUI Mode of Kali-Linux or you can say Nethunter. You can easily access user and root privileges. `` Official link `` <a href
="https://www.kali.org/docs/nethunter/nethunter-rootless">Kali-Nethunter</a>.

<img src="https://github.com/adarshaddee/Kali-Nethunter/blob/main/images/kali-nethunter.png" alt="Kali nethunter" width="100%" />

# Install
> Hey there, this is the simple process of installing Kali-Nethunter in Termux (OR Non-Rooted Device). This tool is made for Android (OR Android Device).

## One Line Install

```
apt update && apt upgrade -y && apt-get install git screenfetch neofetch wget -y && git clone https://github.com/adarshaddee/Kali-Nethunter.git 
```

## Execution
```
cd Kali-Nethunter
```

```
chmod +x kali-Nethunter
```

```
./kali-nethunter
```

### Go for help via ``./kali-nethunter -h``

# Support
> hey there, You can subscribe <a href="https://youtube.com/c/mridealhat">Mr Idealhat</a> for interesting videos OR follow <a href="https://mridealhaat.blogspot.com">Mr Idealhat</a> Blogger website for interesting blogs. Search <a href="https://www.youtube.com/channel/UCvAp_a_UY_TnAIZlpX8UmMg">"Adarsh Addee"</a> on YouTube and subscribe for my vlog videos. 
